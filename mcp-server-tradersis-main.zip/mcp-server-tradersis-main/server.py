from mcp.server.fastmcp import FastMCP
# This is the shared MCP server instance
mcp = FastMCP("tradersis-mcp")
